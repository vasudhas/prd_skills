---
name: write-spec-evaluator
description: Evaluate an existing PRD or spec — pasted, uploaded, or linked from a connected tool — against a problem-statement quality bar, a seven-anti-pattern checklist, and 14-section template completeness, then deliver a concise, actionable report that sorts fixes into Must-fix / Quick fix / Okay-to-have and highlights what's already working. Use when the user asks to "review this PRD", "evaluate my spec", "is this PRD any good", "what's missing from this doc", "grade this", or explicitly invokes /write-spec-evaluator. This skill scores and critiques an existing document; it does not draft one — for that, use write-spec or write-spec-template.
argument-hint: "<paste the PRD, or a link/reference to it>"
---

# Write Spec — Evaluator

Score an existing PRD and hand back specific, actionable fixes. This is a critique tool, not a drafting tool — do not rewrite sections wholesale unless the user explicitly asks for a rewrite after seeing the evaluation.

## When to use this vs. the other two

- User has a PRD (theirs, a colleague's, a template output) and wants it assessed → **this skill**.
- User wants a document drafted from an idea → **write-spec**.
- User wants a blank template to fill in themselves → **write-spec-template**.

## Workflow

### 1. Get the document

Accept the PRD as pasted text, an uploaded file, or a pointer into a connected tool (project tracker, knowledge base). If nothing is provided, ask for it — do not evaluate a description of a PRD; evaluate the actual text.

### 2. Score the problem statement first

Find the section that states the problem (however it's labeled — "Problem," "Background," "Why," etc.) and hold it against this rubric:

| The statement | Verdict |
|---|---|
| "We need to add a search feature to the dashboard." | No — a solution wearing a problem's clothes |
| "Forty percent of users abandon onboarding. They cannot find value in the first three minutes." | Yes — specific, measured, names what's happening to a person |
| "We need to improve the checkout flow." | Half — improve what, and why? A location, not a problem |
| "Enterprise customers lose six hours a week reconciling data across three tools." | Yes — specific, quantified, sourced |
| "Our NPS is 23 and declining. We should redesign the UI." | Half — real number, then jumps straight to a solution |

Score the actual problem statement as **Yes / Half / No** against this pattern, and say specifically why — cite the sentence, don't just assert the verdict.

### 3. Run the seven-anti-pattern check

Go through each and mark it **Clear / Present / Can't tell**, with the specific evidence from the document (a quoted line or a missing section — see copyright note below):

1. **Solution as problem** — does the problem section name a feature/solution instead of a measured effect on users?
2. **Template filling** — do sections have words but no real specificity (numbers, sources, named personas)? This is the most common failure and the easiest to miss on a skim — read for substance, not section-completeness.
3. **Over-specification** — does the solution section spec pixels/implementation instead of scope and perimeter?
4. **Solo authoring** — any sign of review, input, or sign-off from engineering/design/delivery (comments, a reviewers list, a decision log)? Absence isn't proof, but note it as a question if there's no sign at all.
5. **Vague metrics** — for each stated metric, is there a baseline, a target, and a timeframe? Missing any one of the three counts as vague.
6. **Happy path only** — is there a failure modes / edge cases / error states section, and does it go beyond a single throwaway line?
7. **Missing non-goals** — is there an explicit non-goals or out-of-scope section with reasons, not just a list?

When quoting the document to justify a verdict, keep quotes short (a phrase, not paragraphs) and paraphrase the rest.

### 4. Check template completeness

Map the document's actual sections onto the 14-section reference template and note what's missing or thin. Not every PRD needs all 14 — flag missing sections as **findings**, not automatic failures, and let the user judge if the omission is deliberate:

1. One-line summary
2. Why now
3. The problem
4. Who has it
5. Success metrics (baseline + target + timeframe + how derived)
6. Guardrail metrics
7. Solution and user flow
8. Must-haves (login, permissions, security, compliance)
9. Non-goals
10. Failure modes and edge cases
11. Risks, from a pre-mortem
12. Timeline and dependencies
13. Open questions
14. Decision log

### 5. Sort every finding into one severity bucket

Before writing the report, take every finding from Steps 2–4 (problem statement verdict, anti-pattern hits, template gaps) and sort each into exactly one bucket. This sorting — not the findings themselves — is what makes the report actionable, so do it deliberately rather than dumping everything into "must-fix":

- **🔴 Must-fix** — blocking. The document cannot go to build/stakeholders/launch in good conscience with this left as-is. Reserve for: no problem statement or a "No" verdict, any metric missing baseline/target/timeframe entirely, no failure-modes section on a feature where failure is likely or costly, no non-goals at all, or a section that's actively misleading (not just thin).
- **🟡 Quick fix** — real gap, but fixable in minutes and worth doing before the must-fixes even, because it's cheap. Reserve for: a metric that has a target but no timeframe, a non-goal listed with no reason, an assumption stated as fact that just needs the word "assumption" added, a missing one-line summary.
- **⚪ Okay-to-have** — genuinely optional, situational, or a stylistic choice rather than a defect. Reserve for: decision log empty pre-launch (expected), sections merged in a way that still covers the content, a nice-to-have level of detail that would help but whose absence won't hurt anyone.

A finding only belongs in Must-fix if leaving it unfixed would cause a real downstream problem (wrong thing gets built, no way to tell if it worked, scope creep, an AI failure mode ships unhandled) — not merely because a section header is missing. When in doubt, ask what happens if this specific gap is never closed; if the answer is "nothing bad," it's Okay-to-have, not Must-fix.

### 6. Deliver the report

Use this exact structure. It is deliberately short — a busy stakeholder should get the full picture from the headers and bold text alone, and drill into prose only where they need to.

```markdown
# Evaluation: [document name]

**Verdict:** [one line — real PRD, needs work, or build-spec-without-a-PRD, etc.]
**Biggest risk if shipped as-is:** [one line]

## ✅ What's working
- **[Section name]** — [why it's strong, one line]
- **[Section name]** — [why it's strong, one line]
(2–4 items. Skip this only if truly nothing stands out — say so explicitly rather than omitting the header.)

## 🔴 Must-fix
1. **[Issue, named specifically]** → [the concrete fix, not "improve this"]
2. **[Issue]** → [fix]
(Only include what genuinely meets the Must-fix bar from Step 5 — an empty list here is a legitimate, good outcome; say so rather than padding it.)

## 🟡 Quick fixes
1. **[Issue]** → [fix — should be doable in minutes]
2. **[Issue]** → [fix]

## ⚪ Okay-to-have
1. **[Issue]** → [optional improvement]

## Gaps vs. the 14-section template
| Section | Status |
|---|---|
| [section name] | ✅ Strong / 🟡 Thin / 🔴 Missing / — N/A |
(List only sections that are Thin or Missing, plus any explicitly Strong ones worth naming; skip listing every section that's simply fine.)

## Problem statement & anti-pattern notes
- **Problem statement:** Yes / Half / No — [reason, citing the actual line]
- **Anti-patterns present:** [only the ones marked Present in Step 3 — Clear ones don't need restating here since a clean pattern is already reflected in "What's working" or the absence of a Must-fix]
```

Fill in every bracket with specifics from the actual document — a quoted phrase, a named section, a concrete next step. Nothing in the delivered report should read as generic advice that could apply to any PRD.

### 7. Offer next steps

- If there are Must-fix items, offer to hand off to **write-spec** to redraft just those sections with the user's input — but only after the report stands on its own; don't rewrite unprompted.
- If the user wants to fix it themselves, point to **write-spec-template** for the section-by-section prompts.

## Tips

- Be specific and direct, not diplomatically vague — "the metrics section is a bit thin" tells the user nothing they can act on. "Adoption target has no timeframe or baseline" does. Every line in Must-fix/Quick fix/Okay-to-have should name the exact gap and the exact fix, not a category of concern.
- Guard the severity buckets. The report is only actionable if Must-fix stays reserved for things that actually block — if everything lands there, the user is back to an unprioritized wall of feedback, which is the exact problem this format exists to solve.
- Distinguish a genuinely missing element from a stylistic choice. A PRD that merges Sections 5 and 6 into one "Metrics" block isn't automatically wrong — that's Okay-to-have, not Must-fix, unless guardrails are simply absent.
- Always fill in "What's working," even briefly. A report that's 100% gaps reads as unbalanced and is less likely to be acted on than one that also confirms what's already solid.
- Do not soften a real Must-fix to avoid an awkward conversation — a solo-authored, happy-path-only PRD heading into a launch is exactly the kind of thing this skill exists to catch before it ships, not after.
- Never reproduce large verbatim chunks of the user's document back at them in the evaluation — quote short phrases only, paraphrase or reference sections by name for everything else.
- Keep the whole report scannable — this is something someone acts on in two minutes, not reads as prose. If a section of your report is running long, that's a sign to move detail into a one-line fix rather than a paragraph.
