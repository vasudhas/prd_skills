---
name: write-spec
description: Write a feature spec or PRD from a problem statement or feature idea. Use when turning a vague idea or user request into a structured document, scoping a feature with goals and non-goals, defining success metrics and acceptance criteria, or breaking a big ask into a phased spec. Applies a 14-section PRD template, a problem-statement quality bar, and a seven-anti-pattern checklist before the document is considered done.
argument-hint: "<feature or problem statement>"
---

# Write Spec

> If you see unfamiliar placeholders or need to check which tools are connected, see [CONNECTORS.md](../../CONNECTORS.md).

Write a feature specification or product requirements document (PRD) — and make sure it earns the name.

Two related skills exist alongside this one:
- **write-spec-template** — hands over the blank template and prompting questions so the user drafts the PRD themselves, without AI writing the content.
- **write-spec-evaluator** — scores an existing PRD (drafted here, by the user, or by someone else) against the quality bar in this skill and suggests fixes.

Offer these when relevant: if the user wants to write it themselves, point them at write-spec-template instead of drafting for them; if they paste in a finished or half-finished PRD asking "is this good", point them at write-spec-evaluator instead of rewriting it from scratch.

## Usage

```
/write-spec $ARGUMENTS
```

## The Six-Step PRD Process

A PRD is not the six weeks of work that precede it, but a symptom of it. Keep this in view while running the workflow below:

| Step | Time | What happens |
|---|---|---|
| **Immerse** | weeks | Live in the problem — talk to users, read support tickets, watch the data |
| **Frame** | days | Turn the mess into a sharp problem statement |
| **Explore** | days | Look at multiple solutions before committing to one |
| **Align** | days | Get engineering, design, and stakeholders on the same page |
| **Narrate** | hours | Write the document |
| **Evolve** | forever | Update it as reality corrects your assumptions |

Only one of these six steps produces the document — writing is the second-smallest box on the diagram. This skill is mainly built to help with **Narrate**: turning gathered context into a clean draft, fast. But a good draft still depends on the user having done at least some Immerse/Frame/Explore/Align work, and this skill should not fake that work on their behalf. If the user has a feature name and nothing else, Step 2 below exists to surface how much Immerse/Frame/Explore/Align has actually happened — and to flag it honestly, not paper over it with confident-sounding prose. Evolve is why Section 14 (Decision Log) exists in the template — the PRD does not end at "shipped."

## Workflow

### 1. Understand the Feature

Ask the user what they want to spec. Accept any of:
- A feature name ("SSO support")
- A problem statement ("Enterprise customers keep asking for centralized auth")
- A user request ("Users want to export their data as CSV")
- A vague idea ("We should do something about onboarding drop-off")

### 2. Gather Context

Anchor context-gathering on the **Five Questions That Make a PRD** (detailed below) rather than a generic checklist — they map directly onto the template sections. Be conversational — do not dump all questions at once. Ask the most important ones first and fill in gaps as you go:

1. **Why does this matter** — to users and to the business?
2. **Who has this problem, and how do we know?** — persona plus evidence. If the honest answer is "we assume," say so; do not let it disappear into confident prose.
3. **What does success look like, in numbers?** — baseline, target, timeframe, and how the target was derived.
4. **How will we solve it** — scope, non-goals, user flow?
5. **When will we deliver, and what are the risks?**

Also ask about constraints (technical, timeline, regulatory) and prior art (has this been attempted before?).

### 3. Pull Context from Connected Tools

If **~~project tracker** is connected:
- Search for related tickets, epics, or features
- Pull in any existing requirements or acceptance criteria
- Identify dependencies on other work items

If **~~knowledge base** is connected:
- Search for related research documents, prior specs, or design docs
- Pull in relevant user research findings
- Find related meeting notes or decision records

If **~~design** is connected:
- Pull related mockups, wireframes, or design explorations
- Search for design system components relevant to the feature

If these tools are not connected, work entirely from what the user provides. Do not ask the user to connect tools — just proceed with available information.

### 4. Check the Problem Statement Before Drafting

Before generating the full document, hold the problem statement up against this bar. Do not proceed to a full draft on a statement that fails it — push back once and ask for the missing specificity or evidence first.

| The statement | Verdict |
|---|---|
| "We need to add a search feature to the dashboard." | **No.** A direct solution wearing a problem's clothes. |
| "Forty percent of users abandon onboarding. They cannot find value in the first three minutes." | **Yes.** Specific, measured, and says what is happening to a person. |
| "We need to improve the checkout flow." | **Half.** Improve what, and why? This is a location, not a problem. |
| "Enterprise customers lose six hours a week reconciling data across three tools." | **Yes.** Specific, quantified, and sourced from interviews or analytics. |
| "Our NPS is 23 and declining. We should redesign the UI." | **Half.** Started well with a real number and then jumped to a solution in the same breath. |

The pattern: a good problem statement names a specific, measured effect on a specific person or segment, sourced from evidence — and stops there, without smuggling in the solution.

### 5. Generate the PRD

Produce a structured PRD using the **14-section template** below. Do not skip sections — if one genuinely does not apply, keep the header and write "N/A — [why]" rather than deleting it; a missing section reads as an oversight, an explicit N/A reads as a decision.

### 6. Run the Anti-Pattern Check

Before handing the draft back, check it against the **Seven Anti-Patterns** below. Flag any that apply and fix what you can before presenting the document — do not just mention them in passing.

### 7. Review and Iterate

After generating the PRD:
- Ask the user if any sections need adjustment
- Offer to expand on specific sections
- Offer to create follow-up artifacts (design brief, engineering ticket breakdown, stakeholder pitch)
- If the user wants a second opinion on the draft later, that is what write-spec-evaluator is for

## Seven Anti-Patterns

Check every draft against these before calling it done:

1. **Solution as problem.** "Improve the checkout flow because people hate it." A location or a feature name is not a problem statement.
2. **Template filling.** Roughly ninety percent of PRDs in the wild are this, and the number is rising with AI. A section with words in it is not the same as a section with thought in it — do not let this skill produce the former.
3. **Over-specification.** Defining everything instead of discussing it. Section 7 (Solution and User Flow) should describe the perimeter, not the pixels — leave room for the team to work out the details together.
4. **Solo authoring.** A PRD is a collaboration tool. One written entirely alone, with no input from engineering, design, or the delivery team, is a memo wearing a PRD's clothes. Flag this to the user if the draft was built from their input alone with no team context pulled in.
5. **Vague metrics.** No baseline, no target, no timeframe — which means nobody can ever call it a failure. Every metric in Sections 5 and 6 needs all three.
6. **Happy path only.** No plan for what happens when the thing goes wrong. In an AI product this is fatal, because the AI answering incorrectly is not an edge case — it is Tuesday. This is what Section 10 exists to force.
7. **Missing non-goals.** Say explicitly what you are not doing, and why. "We are optimizing revenue this quarter, so a short-term hit to margin is acceptable" is a sentence that prevents three arguments later. This is what Section 9 exists to force.

## Five Questions That Make a PRD

Everything else in this skill is scaffolding around these five. If a draft answers these five questions well, it is a real PRD; if it doesn't, no amount of template-filling will fix it.

1. **Why does this problem matter, to users and to the business?** Spend real time here — this is not the place to save time.
2. **Who has this problem, and how do we know?** If the honest answer to "how do we know" is "we assume," write the word *assumption* — do not dress it up as evidence.
3. **What does success look like, in numbers?** Estimates and guesstimates, never fully accurate, and they force outcome thinking. How the number was arrived at matters more than the number itself.
4. **How will we solve this: scope, non-goals, user flow?** Worked out with the delivery team, not handed to them.
5. **When will we deliver, and what are the risks?** Also worked out with the team — never quote a timeline to a salesperson without engineering in the room.

## The 14-Section PRD Template

Copy this, then delete only the sections the team genuinely does not need — and say why in a one-line note where the section used to be.

### 1. One-line summary
What we are doing and for whom, in a sentence a salesperson could repeat.

### 2. Why now
The business context. What changed to make this the right quarter.

### 3. The problem
Specific, measured, sourced. No feature names — see the problem statement quality bar in Step 4 of the workflow.
- Who experiences this problem and how often
- What is the cost of not solving it (user pain, business impact, competitive risk)
- Ground it in evidence: user research, support data, metrics, or customer feedback

### 4. Who has it
The persona, and the evidence. Mark assumptions as assumptions.
- Be specific enough to be meaningful ("enterprise admin," not "user")
- If multiple personas are affected, name each and how the problem differs for them

### 5. Success metrics
Name, baseline, target, timeframe — plus how the target was derived.

**Leading indicators** (change in days to weeks): adoption rate, activation rate, task completion rate, time to complete, error rate, feature usage frequency.

**Lagging indicators** (change over weeks to months): retention impact, revenue impact, NPS/satisfaction change, support ticket reduction, competitive win rate.

Set both a "success" threshold and a "stretch" target, and specify the measurement method (what tool, what query) and evaluation window (1 week, 1 month, 1 quarter).

### 6. Guardrail metrics
What must not get worse while we chase Section 5's targets. E.g., a search feature that improves task completion but tanks page load time has not actually won.

### 7. Solution and user flow
High level. The perimeter, not the pixels — this is where over-specification (Anti-pattern 3) tends to creep in.

If the feature serves multiple personas or has meaningfully distinct paths, write user stories to organize the flow: "As a [user type], I want [capability] so that [benefit]." Order by priority. Common mistakes: too vague ("I want the product to be faster"), solution-prescriptive ("I want a dropdown menu" — describe the need, not the widget), no stated benefit, or too large ("I want to manage my team" — break it up).

Where useful, categorize requirements with MoSCoW:
- **Must have (P0):** the feature isn't viable without these. Ask "would we really not ship without this?" — be ruthless, if everything is P0 nothing is.
- **Should have (P1):** meaningfully better, but the core use case works without them. Often becomes the fast-follow.
- **Could have (P2):** explicitly out of scope for v1, documented so it doesn't get accidentally designed out.

### 8. Must-haves
Login, permissions, security, compliance. Do not assume people know — write these out even when they feel obvious, because they are exactly what gets missed under deadline pressure.

### 9. Non-goals
What we are explicitly not doing this time, and why. This is Anti-pattern 7 — do not let this section go empty. For each non-goal, name the reason it's out (not enough impact, too complex, separate initiative, premature).

### 10. Failure modes and edge cases
What happens when it breaks, when data is missing, when the model is wrong. This is Anti-pattern 6 — a happy-path-only spec is not done. For an AI feature specifically, treat "the model answers incorrectly" as a designed-for case, not an edge case.

### 11. Risks, from the pre-mortem
Run an actual pre-mortem: imagine the feature has failed, then write five real reasons it failed, and the mitigation for each. This produces sharper risks than a generic "what could go wrong" list.

### 12. Timeline and dependencies
Written with engineering, not for them. Never quote a timeline before that conversation has happened.

### 13. Open questions
The honest list — this section proves the document is alive. Tag each with who needs to answer it (engineering, design, legal, data, stakeholder) and whether it's blocking or non-blocking. Do not include questions the draft can already answer from context; a fake open question is worse than none.

### 14. Decision log
What we changed, when, and what we learned that caused it. Empty at launch — this is the section that ties the document back to **Evolve**, the sixth step of the process. Remind the user to come back and fill this in as the feature ships and reality corrects the plan.

## Acceptance Criteria

For requirements under Section 7/8, write acceptance criteria in Given/When/Then format or as a checklist.

**Given/When/Then**:
- Given [precondition or context]
- When [action the user takes]
- Then [expected outcome]

Example:
- Given the admin has configured SSO for their organization
- When a team member visits the login page
- Then they are automatically redirected to the organization's SSO provider

**Checklist format**:
- [ ] Admin can enter SSO provider URL in organization settings
- [ ] Team members see "Log in with SSO" button on login page
- [ ] SSO login creates a new account if one does not exist
- [ ] SSO login links to existing account if email matches
- [ ] Failed SSO attempts show a clear error message

Cover the happy path, error cases, and edge cases (see Section 10). Be specific about expected behavior, not implementation. Avoid ambiguous words — "fast," "user-friendly," "intuitive" — define what they mean concretely.

## Scope Management

### Recognizing Scope Creep
Scope creep happens when:
- Requirements keep getting added after the spec is approved
- "Small" additions accumulate into a significantly larger project
- The team is building features no user asked for ("while we're at it...")
- The launch date keeps moving without explicit re-scoping
- Stakeholders add requirements without removing anything

### Preventing Scope Creep
- Non-goals (Section 9) are not optional — they are the primary defense
- Require that any scope addition comes with a scope removal or timeline extension
- Separate "v1" from "v2" clearly in the spec
- Review the spec against Section 3 (the problem) — does everything serve it?
- Time-box investigations: "If we cannot figure out X in 2 days, we cut it"
- Create a "parking lot" for good ideas that are not in scope

## Output Format

Use markdown with clear headers, in the 14-section order above. Keep the document scannable — busy stakeholders should be able to read just the headers and bold text to get the gist.

## Tips

- Be opinionated about scope. A tight, well-defined spec beats an expansive vague one.
- If the user's idea is too big for one spec, suggest breaking it into phases and spec the first phase.
- Run the problem statement (Step 4) and the anti-pattern check (Step 6) on every draft — do not skip them because the user seems in a hurry. A fast bad PRD costs more time later than a slightly slower good one.
- If the user wants to draft it themselves rather than have this skill write it, hand off to write-spec-template.
- If the user brings you a PRD to critique rather than to write, hand off to write-spec-evaluator.
